package tests;

import game.Apple;
import game.Snake;

import java.awt.*;

import static org.junit.Assert.*;

public class AppleTest {
    @org.junit.Test
    public void Generate_Apple() {

        Snake snake = new Snake();
        Apple apple = new Apple();


        apple.UpdateAvailablePositions(snake);

        for (int i = 0; i < 10; i++) {

            apple.UpdatePosition();

            boolean result = (apple.GetPos().x == snake.GetHead().x && apple.GetPos().y == snake.GetHead().y);
            for (Point p : snake.GetBody()) {

                result = result || (apple.GetPos().x == p.x && apple.GetPos().y == p.y);


            }
            assertFalse(result);
        }
    }
}