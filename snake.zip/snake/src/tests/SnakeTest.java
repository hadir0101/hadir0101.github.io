package tests;

import game.Apple;
import game.Globals;
import game.Snake;

import static org.junit.Assert.*;

public class SnakeTest {

    @org.junit.Test
    public void eatApple() {
        Snake snake = new Snake();
        Apple apple = new Apple();
        apple.GetPos().x = 20;
        apple.GetPos().y = 20;
        assertFalse(snake.EatApple(apple));

        apple.GetPos().x = snake.GetHead().x;
        apple.GetPos().y = snake.GetHead().y;
        assertTrue(snake.EatApple(apple));
    }

    @org.junit.Test
    public void Test_snake_growth() {
        Snake snake = new Snake();
        Apple apple = new Apple();
        apple.GetPos().x = snake.GetHead().x;
        apple.GetPos().y = snake.GetHead().y;

        int length = snake.GetBody().size();

        snake.EatApple(apple);

        assertEquals(length + 1, snake.GetBody().size());

    }

    @org.junit.Test
    public void Test_TailCollision() {
        Snake snake = new Snake();


        snake.GetHead().x = 0;
        snake.GetHead().y = 0;

        assertTrue(snake.IsDead());


    }


    @org.junit.Test
    public void Test_EdgeCollision() {
        Snake snake = new Snake();


        snake.GetHead().x = -1;
        snake.GetHead().y = 0;

        assertTrue(snake.IsDead());
        snake.GetHead().x = 0;
        snake.GetHead().y = -1;

        assertTrue(snake.IsDead());
        snake.GetHead().x = Globals.MAP_SIZE;
        snake.GetHead().y = 0;

        assertTrue(snake.IsDead());
        snake.GetHead().x = 0;
        snake.GetHead().y = Globals.MAP_SIZE;

        assertTrue(snake.IsDead());


    }
}

