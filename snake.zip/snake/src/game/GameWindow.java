package game;

import javax.swing.*;
import java.awt.*;

public class GameWindow extends JFrame {

    private Map map;

    public GameWindow() {
        setTitle("game.Snake");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        startGame();

        // ************* center window
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int x = (screenSize.width - getWidth()) / 2;
        int y = (screenSize.height - getHeight()) / 2;
        setLocation(x, y);
    }

    private void startGame() {
        getContentPane().removeAll();

        JLabel scoreLabel = new JLabel("Score: 0");
        JLabel bestScoreLabel = new JLabel("Best score: 0");

        String[] cols = {"Rank", "Score"};
        Integer[][] data = {{1, 0}, {2, 0}, {3, 0}};
        JTable table = new JTable(data, cols);

        JPanel scorePanel = new JPanel();
        scorePanel.setBackground(Color.GRAY);
        scorePanel.setLayout(new GridLayout(10, 1));
        scorePanel.add(scoreLabel);
        scorePanel.add(bestScoreLabel);
        scorePanel.add(new JLabel("Leaderboard:"));
        scorePanel.add(table);
        table.setEnabled(false);

        map = new Map(scoreLabel, bestScoreLabel, table, () -> startGame());
        add(map, BorderLayout.WEST);
        add(scorePanel, BorderLayout.EAST);
        getContentPane().validate();
        pack();
        setVisible(true);
    }

}


