package game;

public enum Direction
{
    Up, Down, Left, Right
}
