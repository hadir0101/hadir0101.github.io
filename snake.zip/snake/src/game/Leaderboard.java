package game;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Leaderboard implements Serializable {
    private List<Integer> scores = new ArrayList<>(3);

    public List<Integer> getScores() {
        return scores;
    }

    public void addScore(int score) {
        int index = -1;
        for (int i = 0; i < scores.size(); ++i) {
            if (score > scores.get(i)) {
                index = i;
                break;
            }
        }

        if (index > -1) {
            scores.add(index, score);
            scores.remove(scores.size() - 1);
        }
    }

    public static void save(Leaderboard leaderboard) {
        try {
            ObjectOutputStream file = new ObjectOutputStream(new FileOutputStream("leaderboard.snake"));
            file.writeObject(leaderboard);
            file.close();
        } catch (Exception e) {
        }
    }

    public static Leaderboard load() {
        Leaderboard leaderboard = new Leaderboard();
        try {
            ObjectInputStream file = new ObjectInputStream(new FileInputStream("leaderboard.snake"));
            Leaderboard tmp = (Leaderboard) file.readObject();
            leaderboard.scores = tmp.scores;
            file.close();
        } catch (Exception e) {
            leaderboard.scores.add(0);
            leaderboard.scores.add(0);
            leaderboard.scores.add(0);
        }

        return leaderboard;
    }
}
