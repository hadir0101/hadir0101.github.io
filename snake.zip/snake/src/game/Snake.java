package game;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Snake implements Drawable {
    private Point head;
    private Point velocity;
    private List<Point> tail;
    private static int BASE_SNAKE_LENGTH = 5;

    public Snake() {
        tail = new ArrayList<>(BASE_SNAKE_LENGTH);
        for (int i = BASE_SNAKE_LENGTH - 1; i > -1; --i) tail.add(new Point(i * Globals.CELL_SIZE, 0));
        head = new Point(tail.size() * Globals.CELL_SIZE, 0);
        velocity = new Point(1, 0);
    }

    public Point GetHead() {
        return head;
    }

    public List<Point> GetBody() {
        List<Point> body = new ArrayList<>();
        body.add(head);
        body.addAll(tail);
        return body;
    }

    @Override
    public void Draw(Graphics g) {
        g.setColor(new Color(28, 208, 72));
        for (Point block : tail) g.fillRect(block.x, block.y, Globals.CELL_SIZE, Globals.CELL_SIZE);
        // TODO remove
        g.setColor(new Color(8, 179, 46));
        g.fillRect(head.x, head.y, Globals.CELL_SIZE, Globals.CELL_SIZE);
    }

    public void Move() {
        //changing the position of the tail cell by cell
        for (int i = tail.size() - 1; i > 0; --i) {
            tail.get(i).x = tail.get(i - 1).x;
            tail.get(i).y = tail.get(i - 1).y;
        }
        tail.get(0).x = head.x;
        tail.get(0).y = head.y;
        //head new position
        head.x += Globals.CELL_SIZE * velocity.x;
        head.y += Globals.CELL_SIZE * velocity.y;
    }

    public boolean EatApple(Apple apple) {
        if (apple.GetPos().x == head.x && apple.GetPos().y == head.y) {
            Point last = tail.get(tail.size() - 1);
            tail.add(new Point(last.x, last.y));
            return true;
        }
        return false;
    }

    public void Turn(Direction direction) {
        // to prevent the snake from going back on his tail
        if ((direction == Direction.Left || direction == Direction.Right) && tail.get(0).y == head.y) return;
        if ((direction == Direction.Up || direction == Direction.Down) && tail.get(0).x == head.x) return;
//
        switch (direction) {
            case Up:
                velocity.x = 0;
                velocity.y = -1;
                break;
            case Down:
                velocity.x = 0;
                velocity.y = 1;
                break;
            case Left:
                velocity.x = 1;
                velocity.y = 0;
                break;
            case Right:
                velocity.x = -1;
                velocity.y = 0;
                break;
        }
    }

    public boolean IsDead() {
        return DetectEdgeCollision() || DetectTailCollision();
    }

    private boolean DetectEdgeCollision() {
        if (head.x + Globals.CELL_SIZE > Globals.MAP_SIZE) return true;
        if (head.x < 0) return true;
        if (head.y + Globals.CELL_SIZE > Globals.MAP_SIZE) return true;
        return head.y < 0;
    }

    private boolean DetectTailCollision() {
        for (int i = 1; i < tail.size(); ++i)
            if (head.x == tail.get(i).x && head.y == tail.get(i).y) return true;
        return false;
    }
}
