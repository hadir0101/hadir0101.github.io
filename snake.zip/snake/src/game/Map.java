package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Map extends JPanel implements ActionListener {
    private int score = 0;
    private int bestScore = 0;
    private final Leaderboard leaderboard;
    private final Snake snake = new Snake();
    private final Apple apple = new Apple();
    private final Timer timer;
    private final JLabel scoreLabel;
    private final JLabel bestScoreLabel;
    private final JTable table;
    private boolean gameOver = false;
    private final Runnable onGameOver;

    public Map(JLabel scoreLabel, JLabel bestScoreLabel,  JTable table, Runnable onGameOver) {
        this.onGameOver = onGameOver;
        this.scoreLabel = scoreLabel;
        this.bestScoreLabel = bestScoreLabel;
        this.table = table;
//**********************

        leaderboard = Leaderboard.load();
        updateScoresTable();
        bestScore = leaderboard.getScores().get(0);
        bestScoreLabel.setText("Best score: " + bestScore);

        setPreferredSize(new Dimension(Globals.MAP_SIZE, Globals.MAP_SIZE));
        setFocusable(true);
        addKeyListener(new KeyHandler());
        timer = new Timer(200, this);
        scoreLabel.setText("Score: " + score);
        apple.UpdateAvailablePositions(snake);
        apple.UpdatePosition();
        timer.start();
        gameOver = false;
    }

    //*******************************
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        snake.Draw(g);
        apple.Draw(g);
    }

    private void updateScoresTable() {
        for (int i = 0; i < leaderboard.getScores().size(); i++) {
            Integer score = leaderboard.getScores().get(i);
            table.getModel().setValueAt(score, i, 1);
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (gameOver) return;
        if (snake.IsDead()) {
            gameOver = true;
            GameOver();
            return;
        }
        snake.Move();
        apple.UpdateAvailablePositions(snake);
        if (snake.EatApple(apple)) {
            apple.UpdatePosition();
            UpdateScore();
        }
        repaint();
    }

    private void UpdateScore() {
        score += 10;
        scoreLabel.setText("Score: " + score);
        if (score > bestScore) {
            bestScore = score;
            bestScoreLabel.setText("Best score: " + bestScore);
        }
    }

    private void GameOver() {
        timer.stop();
        leaderboard.addScore(bestScore);
        Leaderboard.save(leaderboard);

        JDialog dialog = new JDialog();
        dialog.setTitle("Game Over");
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setPreferredSize(new Dimension(400, 200));
        setFocusable(true);

        // so when we click on the X the game itself closes
        dialog.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        JButton restart = new JButton("Restart");
        restart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
                onGameOver.run();
            }
        });

        JButton quit = new JButton("Quit");
        quit.addActionListener((e) -> System.exit(0));

        dialog.add(new JLabel("Game Over"), BorderLayout.NORTH);
        dialog.add(restart, BorderLayout.CENTER);
        dialog.add(quit, BorderLayout.SOUTH);

        // to center the layout of GO
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int x = (screenSize.width - dialog.getWidth()) / 2;
        int y = (screenSize.height - dialog.getHeight()) / 2;
        dialog.setLocation(x, y);

        dialog.setVisible(true);
        dialog.pack();

    }

    private class KeyHandler extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            Direction direction = null;
            if (e.getKeyCode() == KeyEvent.VK_W) direction = Direction.Up;
            else if (e.getKeyCode() == KeyEvent.VK_S) direction = Direction.Down;
            else if (e.getKeyCode() == KeyEvent.VK_A) direction = Direction.Right;
            else if (e.getKeyCode() == KeyEvent.VK_D) direction = Direction.Left;
            if (direction != null) snake.Turn(direction);
        }
    }
}
