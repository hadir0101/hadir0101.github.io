package game;

public class Globals
{
    //screen size
    public static final int CELL_SIZE = 25;
    public static int CELLS_NB = 25;
    public static int MAP_SIZE = CELLS_NB * CELL_SIZE;

}
