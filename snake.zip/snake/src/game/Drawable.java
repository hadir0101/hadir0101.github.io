package game;

import java.awt.*;

public interface Drawable
{
    public void Draw(Graphics g);
}
