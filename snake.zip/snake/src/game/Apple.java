package game;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Apple implements Drawable
{
    private Point pos = new Point();
    private final Random random = new Random();
    private final List<Point> availablePositions = new ArrayList<>(Globals.CELLS_NB * Globals.CELLS_NB);

    public Point GetPos() { return pos; }

    public void UpdatePosition()
    {
        int index = random.nextInt(availablePositions.size());
        pos = availablePositions.get(index);
    }

    public void UpdateAvailablePositions(Snake snake)
    {
        for (int i = 0; i < Globals.CELLS_NB; ++i)
        {
            for (int j = 0; j < Globals.CELLS_NB; ++j)
            {
                Point point = new Point(i * Globals.CELL_SIZE, j * Globals.CELL_SIZE);
                if (snake.GetBody().contains(point)) continue;
                availablePositions.add(point);
            }
        }
    }

    @Override
    public void Draw(Graphics g)
    {
        g.setColor(new Color(208, 28, 28));
        g.fillRect(pos.x, pos.y, Globals.CELL_SIZE, Globals.CELL_SIZE);
    }
}
