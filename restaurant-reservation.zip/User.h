#pragma once

#include "Date.h"
#include "Admin.h"
#include "SmartPointer.h"

enum Choice
{
    BOOK_TABLE = 1,
    CANCEL = 2,
    POSTPONE = 3,
    BOOK_RESTAURANT = 4,
    QUIT = 5,
};

class User
{
private:
    SmartPointer<Admin>& admin;
    bool exit = false;

private:
    ReservationDetails GetReservation();
    Date GetDate();
public:
    User(SmartPointer<Admin>& admin);

    inline bool running() const { return !exit; }

    void PrintMenu() const;

    void GetChoice();

    void BookTable();

    void CancelBooking();

    void PostponeBooking();

    void BookRestaurant();

};


