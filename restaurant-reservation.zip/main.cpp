#include <iostream>
#include "Admin.h"
#include "SmartPointer.h"
#include "User.h"

int main()
{
    SmartPointer<Admin> admin = new Admin();
    SmartPointer<User> user = new User(admin);

    while (user->running())
    {
        try
        {
            user->PrintMenu();
            user->GetChoice();
        } catch (const std::exception& err)
        {
            std::cout << err.what() << std::endl;
        }
    }
    return 0;
}
