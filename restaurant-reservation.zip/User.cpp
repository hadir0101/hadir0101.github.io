#include "User.h"
#include <iostream>

User::User(SmartPointer<Admin>& admin) : admin(admin) { }

void User::PrintMenu() const
{
    std::cout << "1. Book a table\n"
              << "2. Cancel booking a table\n"
              << "3. Postpone booking\n"
              << "4. Book restaurant\n"
              << "5. Quits\n";
}

void User::GetChoice()
{
    int choice = -1;
    std::cin >> choice;

    switch (choice)
    {
        case BOOK_TABLE:
            BookTable();
            break;
        case CANCEL:
            CancelBooking();
            break;
        case POSTPONE:
            PostponeBooking();
            break;
        case BOOK_RESTAURANT:
            BookRestaurant();
            break;
        case QUIT:
            exit = true;
            break;
        default:
            throw std::exception("Invalid choice");
    }
}

ReservationDetails User::GetReservation()
{
    int tableNumber = 0;
    std::cout << "Enter the table number: ";
    std::cin >> tableNumber;
    while (tableNumber < 1)
    {
        std::cout << "Invalid table number. Enter again: ";
        std::cin >> tableNumber;
    }
    return ReservationDetails(tableNumber, GetDate());
}

Date User::GetDate()
{
    int day = 0;
    std::cout << "Enter the day number: ";
    std::cin >> day;
    while (day < 1 || day > 31)
    {
        std::cout << "Invalid day number. Enter again: ";
        std::cin >> day;
    }

    int month = 0;
    std::cout << "Enter the month number: ";
    std::cin >> month;
    while (month < 1 || month > 12)
    {
        std::cout << "Invalid month number. Enter again: ";
        std::cin >> month;
    }

    int year = 0;
    std::cout << "Enter the year: ";
    std::cin >> year;
    while (year < 2022)
    {
        std::cout << "Invalid year. Enter again: ";
        std::cin >> year;
    }

    return Date(day, month, year);
}

void User::BookTable()
{
    std::cout << "Booking a table" << std::endl;
    try
    {
        admin->Book(GetReservation());
        std::cout << "Table booked successfully\n" << std::endl;
    }
    catch (const std::exception& err)
    {
        std::cout << err.what() << std::endl;
    }
    PrintMenu();
    GetChoice();
}

void User::CancelBooking()
{
    std::cout << "Canceling booking" << std::endl;
    try
    {
        admin->RemoveBooking(GetReservation());
        std::cout << "Booking canceled successfully\n" << std::endl;
    }
    catch (const std::exception& err)
    {
        std::cout << err.what() << std::endl;
    }
    PrintMenu();
    GetChoice();
}

void User::PostponeBooking()
{
    std::cout << "Postpone booking" << std::endl;
    std::cout << "Old booking details" << std::endl;
    const ReservationDetails& oldDetails = GetReservation();
    std::cout << "New booking details" << std::endl;
    const ReservationDetails& newDetails = GetReservation();

    try
    {
        admin->PostponeBooking(oldDetails, newDetails);
        std::cout << "Booking postponed successfully\n" << std::endl;
    }
    catch (const std::exception& err)
    {
        std::cout << err.what() << std::endl;
    }
    PrintMenu();
    GetChoice();
}

void User::BookRestaurant()
{
    try
    {
        admin->RentRestaurant(GetDate());
        std::cout << "Restaurant booked successfully\n" << std::endl;
    }
    catch (const std::exception& err)
    {
        std::cout << err.what() << std::endl;
    }
    PrintMenu();
    GetChoice();
}
