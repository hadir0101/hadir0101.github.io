#pragma once

template<class T>
class SmartPointer
{
private:
    T* ptr = nullptr;

public:
    SmartPointer(T* ptr = nullptr) : ptr(ptr) { }

    ~SmartPointer() { delete ptr; }

    T* operator->() { return ptr; }
};
