#pragma once

#include <vector>
#include "Date.h"
#include "ReservationDetails.h"
#include <string>

class Admin
{
private:
    std::vector<ReservationDetails> reservations;

private:
    void CheckAvailability(const ReservationDetails& details) const;

public:
    Admin();

    ~Admin();

    void Book(const ReservationDetails& details);

    void RemoveBooking(const ReservationDetails& details);

    void PostponeBooking(const ReservationDetails& oldDetails, const ReservationDetails& newDetails);

    void RentRestaurant(const Date& date);

    void SaveReservations() const;

};


