#pragma once

#include "Date.h"
#include <string>

struct ReservationDetails
{
    Date date;
    int tableNumber = 0;

    ReservationDetails(int tableNumber, const Date& date);

    bool operator==(const ReservationDetails& details) const;
};


