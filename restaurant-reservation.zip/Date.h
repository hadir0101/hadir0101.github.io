#pragma once

#include <string>

struct Date
{
    int day = 0, month = 0, year = 0;

    Date(int day, int month, int year) : day(day), month(month), year(year) { }

    bool operator==(const Date& date) const
    {
        return (day == date.day) && (month == date.month) && (year == date.year);
    }

    std::string ToString() const
    {
        return std::to_string(day) + ":" + std::to_string(month) + ":" + std::to_string(year);
    }

};
