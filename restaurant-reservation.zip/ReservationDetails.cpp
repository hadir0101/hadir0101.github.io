#include "ReservationDetails.h"

ReservationDetails::ReservationDetails(int tableNumber, const Date& date)
        : date(date), tableNumber(tableNumber) { }

bool ReservationDetails::operator==(const ReservationDetails& details) const
{
    return tableNumber == details.tableNumber && date == details.date;
}
