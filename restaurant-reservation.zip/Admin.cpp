#include "Admin.h"
#include <string>
#include <fstream>
#include <exception>

Admin::Admin()
{
    std::ifstream file;
    file.open("reservations.txt");
    if (file.fail() || !file.is_open()) return;

    // tableNumber dd:mm:yyyy
    std::string line;
    while (std::getline(file, line))
    {
        int index = line.find(' ');
        int tableNumber = std::stoi(line.substr(0, index));
        std::string date = line.substr(index + 1);
        int firstIdx = date.find(':');
        int lastIdx = date.find_last_of(':');
        int day = std::stoi(date.substr(0, firstIdx));
        int month = std::stoi(date.substr(firstIdx + 1, lastIdx - firstIdx - 1));
        int year = std::stoi(date.substr(lastIdx + 1));
        reservations.push_back(ReservationDetails(tableNumber, Date(day, month, year)));
    }

    file.close();
}

Admin::~Admin() { SaveReservations(); }

void Admin::CheckAvailability(const ReservationDetails& details) const
{
    for (int i = 0; i < reservations.size(); ++i)
    {
        if (reservations[i].tableNumber == -1 && reservations[i].date == details.date)
            throw std::exception("The restaurant is booked");
        if (reservations[i] == details) throw std::exception("Table is already booked");
    }
}

void Admin::Book(const ReservationDetails& details)
{
    CheckAvailability(details);
    reservations.push_back(details);
}

void Admin::RemoveBooking(const ReservationDetails& details)
{
    int index = -1;
    for (int i = 0; i < reservations.size(); ++i)
    {
        if (reservations[i] == details)
        {
            index = i;
            break;
        }
    }

    if (index < 0) throw std::exception("Reservation not found");
    //thank you google and c++ for blessing us with erase
    reservations.erase(reservations.begin() + index);
}

void Admin::SaveReservations() const
{
    std::ofstream file;
    file.open("reservations.txt");
    if (file.fail() || !file.is_open()) return;

    for (int i = 0; i < reservations.size(); ++i)
    {
        std::string data = std::to_string(reservations[i].tableNumber) + " " + reservations[i].date.ToString();
        file << data << "\n";
    }
    file.close();
}

void Admin::PostponeBooking(const ReservationDetails& oldDetails, const ReservationDetails& newDetails)
{

    CheckAvailability(newDetails);
    RemoveBooking(oldDetails);
    Book(newDetails);
}

void Admin::RentRestaurant(const Date& date)
{
    for (int i = 0; i < reservations.size(); ++i)
        if (reservations[i].date == date) throw std::exception("Restaurant is booked");

    reservations.push_back(ReservationDetails(-1, date)); // -1 means all the restaurant is booked
}
